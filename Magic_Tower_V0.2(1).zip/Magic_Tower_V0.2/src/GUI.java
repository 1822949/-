import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class GUI {
	GameData gameData;
	JFrame f;
	JLabel[][] b;
	private JMenuBar menuBar;
	GUI(GameData gameData) {
		this.gameData = gameData;
		f = new JFrame("Magic Tower");
		b = new JLabel[gameData.H][gameData.W];
		for (int i = 0; i < gameData.H; i++) {
			for (int j = 0; j < gameData.W; j++) {
				b[i][j]=new JLabel();
				b[i][j].setBounds(j*100, i*100, 100, 100);
				f.add(b[i][j]);
			}
		}


		JButton upButton = new JButton("Up");
		upButton.setBounds(gameData.W * 100 + 10, 10, 80, 30);
		upButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleInput1("w");
			}
		});
		f.add(upButton);

		JButton downButton = new JButton("Down");
		downButton.setBounds(gameData.W * 100 + 10, 50, 80, 30);
		downButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleInput1("s");
			}
		});
		f.add(downButton);

		JButton leftButton = new JButton("Left");
		leftButton.setBounds(gameData.W * 100 + 10, 90, 80, 30);
		leftButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleInput1("a");
			}
		});
		f.add(leftButton);

		JButton rightButton = new JButton("Right");
		rightButton.setBounds(gameData.W * 100 + 10, 130, 80, 30);
		rightButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleInput1("d");
			}
		});
		f.add(rightButton);

		MenuFromXML menuFromXML = new MenuFromXML("E:\\Menu.XML",f);
		f.setJMenuBar(menuFromXML.getMenuBar());


		f.setSize(gameData.H*100+300, gameData.W*100+40);
		f.setLayout(null);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		refreshGUI();
	}
	public void refreshGUI()
	{
		for (int i = 0; i < gameData.H; i++) {
			for (int j = 0; j < gameData.W; j++) {
				Image scaledImage = chooseImage(gameData.map[gameData.currentLevel][i][j]);
				b[i][j].setIcon(new ImageIcon(scaledImage));
			}
		}
	}
	private static Image chooseImage(int index){
		ImageIcon[] icons = new ImageIcon[10];
		Image scaledImage;
		icons[0]= new ImageIcon("Wall.jpg");
		icons[1]= new ImageIcon("Floor.jpg");
		icons[2]= new ImageIcon("Key.jpg");
		icons[3]= new ImageIcon("Door.jpg");
		icons[4]= new ImageIcon("Stair.jpg");
		icons[5]= new ImageIcon("Exit.jpg");
		icons[6]= new ImageIcon("Hero.jpg");
		icons[7]= new ImageIcon("Potion.jpg");
		icons[8]= new ImageIcon("Monster.jpg");
		if(index>10)
			scaledImage = icons[7].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		else if(index<0)
			scaledImage = icons[8].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		else
			scaledImage = icons[index].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		return scaledImage;
	}

	void handleInput1(String c) {
		int tX = 0, tY = 0;
		if (c.equals("a")) {
			tX = gameData.pX;
			tY = gameData.pY - 1;
		}
		if (c.equals("s")) {
			tX = gameData.pX + 1;
			tY = gameData.pY;
		}
		if (c.equals("d")) {
			tX = gameData.pX;
			tY = gameData.pY + 1;
		}
		if (c.equals("w")) {
			tX = gameData.pX - 1;
			tY = gameData.pY;
		}
		if (gameData.map[gameData.currentLevel][tX][tY] == 2) {
			gameData.keyNum++;
			moveHero1(tX, tY);
		} else if (gameData.map[gameData.currentLevel][tX][tY] == 3 && gameData.keyNum > 0) {
			gameData.keyNum--;
			moveHero1(tX, tY);
		} else if (gameData.map[gameData.currentLevel][tX][tY] == 4) {
			gameData.map[gameData.currentLevel][gameData.pX][gameData.pY] = 1;
			gameData.currentLevel++;
			for (int i = 0; i < gameData.H; i++)
				for (int j = 0; j < gameData.W; j++)
					if (gameData.map[gameData.currentLevel][i][j] == 6) {
						gameData.pX = i;
						gameData.pY = j;
					}
		} else if (gameData.map[gameData.currentLevel][tX][tY] == 5) {
			System.out.print("You Win!!");
			System.exit(0);
		} else if (gameData.map[gameData.currentLevel][tX][tY] > 10) {
			gameData.heroHealth += gameData.map[gameData.currentLevel][tX][tY];
			moveHero1(tX, tY);
		} else if (gameData.map[gameData.currentLevel][tX][tY] == 1) {
			moveHero1(tX, tY);
		} else if (gameData.map[gameData.currentLevel][tX][tY] < 0) {
			if (gameData.map[gameData.currentLevel][tX][tY] + gameData.heroHealth <= 0) {
				System.out.print("That monster has " + Integer.toString(-gameData.map[gameData.currentLevel][tX][tY])
						+ " power, You Lose!!");
				System.exit(0);
			} else {
				gameData.heroHealth += gameData.map[gameData.currentLevel][tX][tY];
				moveHero1(tX, tY);
			}
		}
		gameData.printMap();
		refreshGUI();
	}
	void moveHero1(int tX, int tY) {
		gameData.map[gameData.currentLevel][gameData.pX][gameData.pY] = 1;
		gameData.map[gameData.currentLevel][tX][tY] = 6;
		gameData.pX = tX;
		gameData.pY = tY;
	}

	private void parseXML(String filePath) {
		try {
			File inputFile = new File(filePath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("menu1");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node node = nList.item(temp);

				if (node.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) node;
					String title = element.getAttribute("title");
					JMenu menu = new JMenu(title);

					NodeList subMenuList = element.getChildNodes();
					for (int i = 0; i < subMenuList.getLength(); i++) {
						Node subNode = subMenuList.item(i);
						if (subNode.getNodeType() == Node.ELEMENT_NODE) {
							Element subElement = (Element) subNode;
							JMenuItem menuItem = new JMenuItem(subElement.getAttribute("title"));
							// Assuming isFunction values match method names in an ActionListener
							String actionCommand = subElement.getAttribute("isFunction");
							menuItem.setActionCommand(actionCommand);
							menuItem.addActionListener(e -> handleAction(actionCommand));
							menu.add(menuItem);
						}
					}

					menuBar.add(menu);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void handleAction(String command) {
		switch (command) {
			case "restartGame":
				f.dispose();
				new GUI(gameData);

				break;
			case "quitGame":
				f.dispose();
				break;
			case "saveGame":
				System.out.println("Save game action.");
				break;
			case "loadGame":
				System.out.println("Load game action.");
				break;
			default:
				System.out.println("Unknown action: " + command);
		}
	}
}
