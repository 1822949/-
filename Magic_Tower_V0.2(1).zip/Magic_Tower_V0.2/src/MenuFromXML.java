import javax.swing.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.awt.*;
import java.io.File;

public class MenuFromXML {

    private JMenuBar menuBar;

    public MenuFromXML(String xmlFilePath,JFrame f) {
        menuBar = new JMenuBar();
        parseXML(xmlFilePath,f);
    }

    private void parseXML(String filePath,JFrame f) {
        try {
            File inputFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("menu1");

            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node node = nList.item(temp);

                if (node.getNodeType() == Node.ELEMENT_NODE) {

                    Element element = (Element) node;
                    String title = element.getAttribute("title");
                    JMenu menu = new JMenu(title);

                    NodeList subMenuList = element.getChildNodes();
                    for (int i = 0; i < subMenuList.getLength(); i++) {
                        Node subNode = subMenuList.item(i);
                        if (subNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element subElement = (Element) subNode;
                            JMenuItem menuItem = new JMenuItem(subElement.getAttribute("title"));
                            // Assuming isFunction values match method names in an ActionListener
                            String actionCommand = subElement.getAttribute("isFunction");
                            menuItem.setActionCommand(actionCommand);
                            menuItem.addActionListener(e -> handleAction(actionCommand,f));
                            menu.add(menuItem);
                        }
                    }

                    menuBar.add(menu);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleAction(String command,JFrame f) {
        switch (command) {
            case "restartGame":
              /*  f.dispose();*/
                MagicTowerMain.restart();

                break;
            case "quitGame":
                System.exit(0);
                System.out.println("Quit game action.");
                break;
            case "saveGame":
                System.out.println("Save game action.");
                break;
            case "loadGame":
                System.out.println("Load game action.");
                break;
            default:
                System.out.println("Unknown action: " + command);
        }
    }

    public JMenuBar getMenuBar() {
        return menuBar;
    }

    public static void main(String[] args) {
       /* JFrame frame = new JFrame("Menu from XML Example");
        MenuFromXML menuFromXML = new MenuFromXML("E:\\Menu.XML");
        frame.setJMenuBar(menuFromXML.getMenuBar());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setVisible(true);*/
    }
}